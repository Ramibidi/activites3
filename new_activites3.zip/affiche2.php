<?php
$bdd = new PDO('mysql:host=localhost;dbname=database;charset=utf8', 'root', '');
//mysql_select_db("database");
$req2 = "SELECT * from commentaires ";
//$res=mysql_query($req);
$reponse2 = $bdd->query($req2);
?>
<center>
<table width="600" border="1">
  <tr bgcolor="#B0E0E6">
     <td>Id</td>
     <td>Texte</td>
     <td>Auteur</td>
     <td>Date_publication</td>
  </tr>
  <?php
  //while($ligne=mysql_fetch_array($reponse)) { 
  while ($ligne2 = $reponse2->fetch(PDO::FETCH_ASSOC)) { ?>
    <tr> 
    <td><?php echo $ligne2['id'];?></td>
    <td><?php echo $ligne2['texte'];?></td>
    <td><?php echo $ligne2['auteur'];?></td>
    <td><?php echo $ligne2['date_publication'];?></td>
    
    
    
 </tr>
  <?php } ?>
</table>
</center>
