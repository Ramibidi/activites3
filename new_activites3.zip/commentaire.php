<h1>Mon premier site PHP</h1>
            <div style="background-color : #E6E6FA ;clear:both;height: 20px">
            <ul style="display:flex; justify-content : space-evenly;">
                <li><a href="index.php" style="color: black"><strong>Home</strong></a></li>
                <li><a href="formulaire.php" style="color: black"><strong>Ajouter un article</strong></a></li>
                <li><a href="affiche.php" style="color: black"><strong>Aritcles</strong></a></li>
               
            </ul>
        </div>
<?php
//include_once("config.php");
?>
<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="style.css"/>
	<meta charset="utf-8">
	<title></title>
</head>
<body>
	<center>
<form method="post" action="config2.php">
	<fieldset>
	<legend style="color: black"> <strong>Commentaires</strong></legend>
	<p>
		<label for="nom">Texte :</label>
		<input type="text" name="text2"  autofocus required/>
    </p>
	
    <p>
		<label for="nom">Auteur :  </label>
		<input type="text" name="auteur2"  autofocus required/>
    </p>
    <p>
		<label for="nom">Date de publication :  </label>
		<input type="date" name="dt2"  autofocus required/>
    </p>
    <input type="submit" name="btn2_ajouter" value="Ajouter" /> 
</body>
</fieldset>
</form>
</center>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<?php
include_once("affiche2.php");
?>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>




<?php
include ('footer.php');
?>
</body>
</html>

</head>
</html>    
   
        
  