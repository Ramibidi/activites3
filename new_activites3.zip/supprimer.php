<?php
$bdd = new PDO('mysql:host=localhost;dbname=database;charset=utf8', 'root', '');

       
  if(isset($_GET['mod']))
  {
      $id = $_GET['mod'];
      $sql = "DELETE FROM `articles` WHERE id='$id'";
      $raquete= $bdd->prepare($sql);
      $raquete->execute();
      header('Location:index.php');
      
      
  }
    
?>