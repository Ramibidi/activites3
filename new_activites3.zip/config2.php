<?php
     //connexion au serveur
     $connexion2 = new PDO('mysql:host=localhost;dbname=database;charset=utf8', 'root', '');
     /*$titre=$_POST['titre'];
     $texte=$_POST['texte'];
     $auteur=$_POST['auteur'];
     $date=$_POST['dt'];
     echo"Votre titre est :".$titre. "<br>Votre texte : ".$texte. "<br>Votre auteur : ".$auteur."<br>Votre date : ".$date;
     $insert=$connexion->prepare("INSERT INTO articles(titre,texte,auteur,date_publication) VALUES(?,?,?,?)");
     $insert->execute(array($titre,$texte,$auteur,$date));
     //header('Location:index.php');
      */
      if(isset($_POST['btn2_ajouter']))
            {
                
                $texte=$_POST['text2']; echo $texte; 
                $auteur=$_POST['auteur2']; echo $auteur; 
                $date=$_POST['dt2']; echo $date;

                $insert=$connexion2->prepare("INSERT INTO commentaires(texte,auteur,date_publication) VALUES(?,?,?)");
                $insert->execute(array($texte,$auteur,$date));
                header('Location:commentaire.php');

            
            }
?>