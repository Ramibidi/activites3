<?php
     //connexion au serveur
     $connexion = new PDO('mysql:host=localhost;dbname=database;charset=utf8', 'root', '');
     /*$titre=$_POST['titre'];
     $texte=$_POST['texte'];
     $auteur=$_POST['auteur'];
     $date=$_POST['dt'];
     echo"Votre titre est :".$titre. "<br>Votre texte : ".$texte. "<br>Votre auteur : ".$auteur."<br>Votre date : ".$date;
     $insert=$connexion->prepare("INSERT INTO articles(titre,texte,auteur,date_publication) VALUES(?,?,?,?)");
     $insert->execute(array($titre,$texte,$auteur,$date));
     //header('Location:index.php');
      */
      if(isset($_POST['btn_ajouter']))
            {
                $titre=$_POST['titre']; echo $titre; 
                $texte=$_POST['texte']; echo $texte; 
                $auteur=$_POST['auteur']; echo $auteur; 
                $date=$_POST['dt']; echo $date;

                $insert=$connexion->prepare("INSERT INTO articles(titre,texte,auteur,date_publication) VALUES(?,?,?,?)");
                $insert->execute(array($titre,$texte,$auteur,$date));
                header('Location:formulaire.php');

            
            }
?>