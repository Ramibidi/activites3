<html>
<head>
<link rel="stylesheet" href="style.css"/>
</head>
<body>
<h1>Mon premier site PHP</h1>
            <div style="background-color : #E6E6FA ;clear:both;height: 20px">
            <ul style="display:flex; justify-content : space-evenly;">
                <li><a href="index.php" style="color: black"><strong>Home</strong></a></li>
                <li><a href="formulaire.php" style="color: black"><strong>Ajouter un aritcle</strong></a></li>
                
               
            </ul>
        </div>
<br/>
<br/>
<br/>
<?php
//mysql_connect("localhost","root","");
$bdd = new PDO('mysql:host=localhost;dbname=database;charset=utf8', 'root', '');
//mysql_select_db("database");
$req = "SELECT * from articles ";
//$res=mysql_query($req);
$reponse = $bdd->query($req);
?>
<center>
<table width="600" border="1">
  <tr bgcolor="#B0E0E6">
     <td>Id</td>
     <td>Titre</td>
     <td>Texte</td>
     <td>Auteur</td>
     <td>Date_publication</td>
  </tr>
  <?php
  //while($ligne=mysql_fetch_array($reponse)) { 
  while ($ligne = $reponse->fetch(PDO::FETCH_ASSOC)) { ?>
    <tr> 
    <td><?php echo $ligne['id'];?></td>
    <td><?php echo $ligne['titre'];?></td>
    <td><?php echo $ligne['texte'];?></td>
    <td><?php echo $ligne['auteur'];?></td>
    <td><?php echo $ligne['date_publication'];?></td>
    <td><button style=" width: 100%;border-radius: 8px; background-color: red;color: black"><a style="color:white" href="supprimer.php?mod=<?php echo  $ligne['id'];?>"><strong>Supprimer</strong></button></td>
    <td><button style=" width: 100%;border-radius: 8px; background-color: green;color: black"><a style="color:white" href="commentaire.php?mod=<?php echo  $ligne['id'];?>"><strong>Commentaire</strong></button></td>
    
    
 </tr>
  <?php } ?>
</table>
</center>

<br/>
<br/>
<br/>

<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<?php
include ('footer.php');
?>

</body>
</html>    
       