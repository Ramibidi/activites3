<html>
<head>
<link rel="stylesheet" href="style.css"/>
<meta charset="utf-8"/>
</head>
<?php
include ('header.php');
?>
<body>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<?php
//require ('formulaire.php');
?>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>





<?php
include ('footer.php');
?>

</body>
</html>
