         
        <h1>Mon premier site PHP</h1>
            <div style="background-color : #E6E6FA ;clear:both; height: 20px">
            <ul style="display:flex; justify-content : space-evenly;">
                <li><a href="index.php" style="color: black"><strong>Home</strong></a></li>
                <li><a href="formulaire.php" style="color: black"><strong>Ajouter un aritcle</strong></a></li>
                <li><a href="affiche.php" style="color: black"><strong>Aritcles</strong></a></li>
                
                
               
            </ul>
        </div>
            
  