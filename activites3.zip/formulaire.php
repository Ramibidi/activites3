<html>
<head>
<meta charset="utf-8"/>
</head>
<body>
<?php
include ('header.php');
?>
<body>
<br/>
<br/>
<br/>
<center>
<form action="cible.php" method="POST">
<strong>Titre :</strong> <input type="text" , name="titre" , value="" >
<br/>
<br/>
<br/>
<strong>Texte :</strong> <input type="text" , name="texte" , value="" >
<br/>
<br/>
<br/>
<strong>Auteur :</strong> <input type="text" , name="auteur" , value="" >
<br/>
<br/>
<br/>
<strong>Date de publication :</strong> <input type="date" ,id="start" , name="date_publication",
       value="2018-07-22",
       min="1990-01-01", max="3000-12-25" >
<br/>
<br/>
<br/>
<br/>
<input type="submit",value="Publier">
</form>
</center>
</body>
</html>