<?php
/*
$host = 'localhost';
$port =3306;
$dbname='database';
$user='root';
$pwd='';
try{
    $newBD=new PDO('mysql:host=$host;port=$port;dbname=$dbname',$user,$pwd);
    echo "Connexion etablie";
}catch(PDOException $e){
    die('Erreur : '.$e->getMessage());
}

*/

//$bdd = new PDO('mysql:host=localhost;dbname=database;charset=utf8', 'root', '');
?>