<?php



 $article['Aricle1']['titre']='Talan';
 $article['Aricle1']['text']='text1';
 $article['Aricle1']['auteur']='Ahmed';
 $article['Aricle1']['date de publication']='01/10/2021';
 

 $article['Aricle2']['titre']='Academy';
 $article['Aricle2']['text']='text2';
 $article['Aricle2']['auteur']='Semi';
 $article['Aricle2']['date de publication']='02/10/2021';
 
 $article['Aricle3']['titre']='Localhost';
 $article['Aricle3']['text']='text3';
 $article['Aricle3']['auteur']='Moncef';
 $article['Aricle3']['date de publication']='03/10/2021';

 $article['Aricle4']['titre']='Php';
 $article['Aricle4']['text']='text4';
 $article['Aricle4']['auteur']='Fairouz';
 $article['Aricle4']['date de publication']='04/10/2021';


 function date_compare($element1, $element2) {
    $datetime1 = strtotime($element1['date de publication']);
    $datetime2 = strtotime($element2['date de publication']);
    return $datetime2 - $datetime1;
} 
  
// Sort the array 
usort($article, 'date_compare');
  
// Print the array
print_r($article) ;
 // print_r($article) ;


// echo $article['Aricle3']['titre'];

 fonction getArticles($nb_article)
 {
    if($nb_article>0)
    {
        print_r($article) ;
    }

    return $article ;
 }
*/
echo $article['Aricle1']['titre'];
?>