<?php
//require('traitemnet.php');
$bdd = new PDO('mysql:host=localhost;dbname=database;charset=utf8', 'root', '');

$titre=$_POST['titre'];
$texte=$_POST['texte'];
$auteur=$_POST['auteur'];
$date=$_POST['date_publication'];
echo"Votre titre est :".$titre. "<br>Votre texte : ".$texte. "<br>Votre auteur : ".$auteur."<br>Votre date : ".$date;
$insert=$bdd->prepare("INSERT INTO articles(titre,texte,auteur,date_publication) VALUES(?,?,?,?)");
$insert->execute(array($titre,$texte,$auteur,$date));
header('Location:index.php');
?>