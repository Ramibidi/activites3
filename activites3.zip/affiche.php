<html>
<head>
</head>
<body>
<?php
include ('header.php');
?>
<body>
<br/>
<br/>
<br/>
<?php
//mysql_connect("localhost","root","");
$bdd = new PDO('mysql:host=localhost;dbname=database;charset=utf8', 'root', '');
//mysql_select_db("database");
$req = "SELECT * from articles ";
//$res=mysql_query($req);
$reponse = $bdd->query($req);
?>
<center>
<table width="802" border="1">
  <tr bgcolor="#B0E0E6">
     <td>Titre</td>
     <td>Texte</td>
     <td>Auteur</td>
     <td>Date_publication</td>
  </tr>
  <?php
  //while($ligne=mysql_fetch_array($reponse)) { 
  while ($ligne = $reponse->fetch(PDO::FETCH_ASSOC)) { ?>
    <tr> 
    <td><?php echo $ligne['titre'];?></td>
    <td><?php echo $ligne['texte'];?></td>
    <td><?php echo $ligne['auteur'];?></td>
    <td><?php echo $ligne['date_publication'];?></td>
    <td><button><a href="modifier.php?mod=<?php echo  $ligne['id'];?>"><strong>Supprimer</strong></button></td>
    
 </tr>
  <?php } ?>
</table>
</center>
</body>
</html>    
       