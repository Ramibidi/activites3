         
        <h1>Mon premier site PHP</h1>
            <div style="background-color : #E6E6FA ;clear:both;">
            <ul style="display:flex; justify-content : space-evenly;">
                <li><a href="index.php"><strong>Home</strong></a></li>
                <li><a href="formulaire.php"><strong>Ajouter un aritcle</strong></a></li>
                <li><a href="affiche.php"><strong>Aritcles</strong></a></li>
               
            </ul>
        </div>
            
  