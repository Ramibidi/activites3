
<html>
<head>
<meta charset="utf-8"/>
</head>
<body>
<?php
//require('traitemnet.php');
$articles = [
    
        'titre' => ($_POST['titre'] )  ,
        'texte' => ($_POST['texte'] ),
        'auteur' => ($_POST['auteur'] ),
        'date' => ($_POST['trip-start'] ),
        
];


$myJSON = json_encode($articles);

echo $myJSON;
/*
//print_r($articles);
//$json = json_encode($articles);
//var_dump($json);
//print_r($json);
$articles['id']=uniqid();
$json = json_encode($articles);
//$json = uniqid();
print_r($json);
//echo $json;
//file_put_contents('article.json', $json);

// file_put_contents('article.json', $json);
            
            //On récupère le contenu du fichier
            $texte = file_get_contents('article.json');
            // print_r(json_decode($texte));
        
            /*
            //On ajoute notre nouveau texte à l'ancien
            $texte .= $json;
            
            //On écrit tout le texte dans notre fichier
             file_put_contents('article.json', $texte);

             function getArticles() 
             {
                $texte = file_get_contents('article.json');
                print_r($texte);

             }
             getArticles();
            
            */
           

            
?>
</body>
</html>