<div style="background-color : #E6E6FA ;clear:both;">
© Copyright - Contact -  Mention legales </div>